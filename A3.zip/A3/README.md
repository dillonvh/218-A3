# 218-A3
To run locally;

npm install

node server.js

Additional Notes:

-I was unable to connect to the csil mongo db so I used mlab instead. Inside server.js you can find the commented out string I used to attempt to connect to the csil mongo server.

-As of right now, I am having issues with viewing my app on http://www.cmpt218.csil.sfu.ca:26568, however, everything runs locally with no issues. I am in contact with help desk working to resolve the issues that prevent my app from running at the url.
